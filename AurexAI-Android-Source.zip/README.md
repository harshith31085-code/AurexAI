# AurexAI Android prototype

This is the first code-based Android prototype for AurexAI.

## Current status
- Dark black-and-gold chat interface.
- User can type messages and see them in the conversation.
- The response is currently a placeholder. It is **not connected to a real AI model yet**.

## Build from a phone using GitHub Actions
1. Create a GitHub account if you do not have one.
2. Create a new repository named `AurexAI`.
3. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
4. Open the repository's **Actions** tab and enable Actions if prompted.
5. The workflow `Build AurexAI APK` runs on the `main` branch. You can also open it and tap **Run workflow**.
6. Open the completed workflow run, scroll to **Artifacts**, and download `AurexAI-debug-apk`.
7. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Important next steps
- Connect a real AI provider through a secure backend. Do not place private API keys in the Android app.
- Add network permission, error handling, privacy policy, and testing before public release.
- A debug APK is for testing, not the final Play Store release.
