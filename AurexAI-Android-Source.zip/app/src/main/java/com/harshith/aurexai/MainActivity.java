package com.harshith.aurexai;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private ScrollView scroll;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        return bg;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 12, 16));
        getWindow().setNavigationBarColor(Color.rgb(12, 12, 16));
        getWindow().getDecorView().setSystemUiVisibility(0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 12, 16));
        root.setPadding(dp(16), dp(10), dp(16), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("AUREX AI", 25, Color.rgb(232, 196, 108));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView subtitle = text("Your personal AI companion", 13, Color.LTGRAY);
        header.addView(title);
        header.addView(subtitle);
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(66)));

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(70, 58, 37));
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(14), 0, dp(14));
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        addMessage("AurexAI", "Hello! I'm AurexAI. This is our first prototype. Right now, the chat interface works, but the live AI engine still needs to be connected.", false);

        TextView note = text("Prototype • AI connection comes next", 11, Color.rgb(160, 160, 170));
        note.setGravity(Gravity.CENTER);
        root.addView(note, new LinearLayout.LayoutParams(-1, dp(24)));

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setPadding(dp(8), dp(5), dp(5), dp(5));
        composer.setBackground(rounded(Color.rgb(31, 31, 38), 22));

        EditText input = new EditText(this);
        input.setHint("Ask AurexAI anything...");
        input.setHintTextColor(Color.rgb(150, 150, 160));
        input.setTextColor(Color.WHITE);
        input.setTextSize(15);
        input.setSingleLine(true);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setPadding(dp(10), dp(8), dp(4), dp(8));
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(48), 1f));

        Button send = new Button(this);
        send.setText("Send");
        send.setTextColor(Color.rgb(18, 18, 18));
        send.setAllCaps(false);
        send.setTextSize(14);
        send.setBackground(rounded(Color.rgb(232, 196, 108), 18));
        composer.addView(send, new LinearLayout.LayoutParams(dp(82), dp(44)));
        root.addView(composer, new LinearLayout.LayoutParams(-1, dp(58)));

        send.setOnClickListener(v -> {
            String prompt = input.getText().toString().trim();
            if (prompt.isEmpty()) return;
            addMessage("You", prompt, true);
            input.setText("");
            ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(input.getWindowToken(), 0);
            addMessage("AurexAI", "I received your message. The live AI engine is not connected yet. We'll connect it in the next development step.", false);
        });

        setContentView(root);
    }

    private void addMessage(String sender, String body, boolean fromUser) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(10), dp(13), dp(10));
        card.setBackground(rounded(
                fromUser ? Color.rgb(47, 43, 34) : Color.rgb(27, 27, 34), 16));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                fromUser ? (int)(getResources().getDisplayMetrics().widthPixels * 0.78f) : -1,
                -2);
        params.setMargins(0, dp(6), 0, dp(6));
        if (fromUser) params.gravity = Gravity.RIGHT;

        TextView name = text(sender, 12,
                fromUser ? Color.rgb(232, 196, 108) : Color.rgb(232, 196, 108));
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView message = text(body, 15, Color.rgb(235, 235, 240));
        message.setPadding(0, dp(4), 0, 0);
        card.addView(name);
        card.addView(message);
        messages.addView(card, params);
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
}
